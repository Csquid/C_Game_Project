#include "head.h"

int main()
{
	Pos *pData = (Pos *)malloc(sizeof(pos));
	Pos *arrowPos = (Pos*)malloc(sizeof(Pos));
	Map *pMap = (Map *)malloc(sizeof(map));
	Menu proMenu;


	arrowPos->setPos(ARROW_X, ARROW_Y);
	Window_Size_Config(Default_Window_Config);

	int menu_chose = 0;
	int checkNumber = 0;

	while (1)
	{
		proMenu.Menu_Title();
		proMenu.Menu_Content();

		menu_chose = Move_Arrow(arrowPos);
		pMap->Menu();

		printf("\nChoose Map\n");
		Sleep(50);
		system("cls");

		if (menu_chose != 0)
		{
			while (1)
			{
				Window_Size_Config(menu_chose);

				Pos* mapPos = (Pos*)malloc(sizeof(mapPos));
				Pos userInfo_xy(1, 1);
				mapPos->x = 0;
				mapPos->y = 0;

				char mapPath[25] = "./maps/";
				const char* mapDefault = "default.txt";
				const char* mapPattern = "pattern.txt";

				int checkEscape = -1;
				int **dPointer;

				switch (menu_chose)
				{
				case 1:
					strcat_s(mapPath, sizeof(mapPath), mapDefault);
			
					mapLoding(&dPointer, mapPath, &mapPos);

					while (1)
					{
						pMap->DrawMap(*mapPos, dPointer);
						checkEscape = Move_Character(*mapPos, &userInfo_xy, 1);
						Sleep(33);
						if (checkEscape == -1)
						{
							break;
						}
					}
					break;
				case 2:
					strcat_s(mapPath, sizeof(mapPath), mapPattern);
					mapLoding(&dPointer, mapPath, &mapPos);

					while (1)
					{
						pMap->DrawMap(*mapPos, dPointer);
						checkEscape = Move_Character(*mapPos, &userInfo_xy, 2);
						Sleep(66);
						if (checkEscape == -1)
						{
							break;
						}
					}
				}
				break;
			}
		}
	}
	free(pData);
	free(pMap);

}